

var ServerTime = 0;
var infoExample = 
{
    SignalStrength: 50,
    LastShown: 1495106073
}

var socket = io("http://45.32.115.235:8081");
socket.on("mac_update", function(data)
{
    // console.log(data);
    receiveUpdate(data);
});

function receiveUpdate(item)
{
    var item_vendor = item.vendor;
    if(item_vendor) item_vendor = item_vendor.toLowerCase();
    ServerTime = item.time;
    if(DeviceDict[item.mac] != undefined)
    {
        DeviceDict[item.mac].SignalStrength = item.sig;
        DeviceDict[item.mac].LastShown = item.time;
    }
    else
    {
        DeviceDict[item.mac] = 
        {
            SignalStrength: item.sig,
            LastShown: item.time,
            SceneObj: undefined,
            Vendor: item_vendor,
            Color: undefined
        }
    }
    // console.log(item_vendor);
    viewUpdate(item);
}

window.setInterval(function(){
    var deadLine = ServerTime - 20000;
    for (var key in DeviceDict) 
    {
        if (DeviceDict.hasOwnProperty(key) && 
            DeviceDict[key].LastShown<deadLine)
        {
            viewDelete(DeviceDict[key]);
            delete DeviceDict[key];
        }
    }
}, 1000);