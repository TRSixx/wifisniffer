http = require('http');
fs = require('fs');
var fs = require('fs');
var stream = fs.createWriteStream("log.txt", {flags:'a'});
var oui = require('oui');
var server;
var socket;

rssi_len = 1
var buffer = '';

function dump_file(content){
    buffer+=content+'\n';
    if(buffer.length>4096){
        stream.write(buffer);
        buffer = '';
    }
}

function getVariable(str, variable) {
    var arr = str.split('&');
    for(uno in arr){
        var pos;
        pos = arr[uno].indexOf(variable+'=');
        if(pos>=0){
            return arr[uno].substr(pos+variable.length+1);
        }
    }
}

function dataProcess(data){
    var arr = data.split('\u0001');
    for(uno in arr){
        var item = arr[uno];
        //some data are useless.
        if(item.length>12){
            var mac_addr = item.substr(0,12);
            var rssi = item.substr(12);
            var rssi_str = '';
        
            for(var i=0; i<rssi.length && i<rssi_len; i++){
                rssi_str += rssi.charCodeAt(i).toString()+' ';
            }
            
            var data_to_send = {
                sig: rssi_str,
                time: Date.now(),
                mac: mac_addr,
                vendor:oui(mac_addr)
            }
            socket.sockets.emit('mac_update', data_to_send);
            var data = Date.now() +':'+ mac_addr+'-'+rssi_str;
            
            console.log(data);
            dump_file(data);
        }
    }
}

server = http.createServer( function(req, res) {

    // console.dir(req.param);

    if (req.method == 'POST') {
        // console.log("POST");
        var body = '';
        var data_sec = '';
        req.on('data', function (data) {
            body += data;
            // console.log("Partial body: " + body);
        });
        req.on('end', function () {
            // console.log("Body: " + body);
            data_sec = getVariable(body, 'data');
            // console.log(data_sec);
            dataProcess(data_sec);
        });
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end('ok');
    }
    else
    {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end('ok');
    }

});

port = 8081;
server.listen(port);
socket = require('socket.io')(server);