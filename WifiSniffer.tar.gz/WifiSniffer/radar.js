var DeviceDict = {};

var SpecialList = {};
SpecialList['acbc328dc46b']=true;
SpecialList['f0b4292b3ae2']=true;
SpecialList['c0ccf851f4de']=true;

var tiempo = 0;
var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera(80, 1, 0.1, 1000);
// var zoom = 10;
// var camera = new THREE.OrthographicCamera( 
//     zoom, -zoom, 
//     zoom*window.innerHeight / window.innerWidth , -zoom*window.innerHeight / window.innerWidth,
//     0, 1000 );
var renderer = new THREE.WebGLRenderer({antialias: true});
renderer.setPixelRatio( window.devicePixelRatio );
renderer.setSize(window.innerWidth, window.innerWidth );
document.getElementById("canvas_region").appendChild(renderer.domElement);

var online = 0;

window.addEventListener( 'resize', onWindowResize, false );
function onWindowResize(){

    camera.aspect = 1;
    camera.updateProjectionMatrix();

    renderer.setSize( window.innerWidth, window.innerWidth );

}

var rings = [
    {innerRadius: 0, outerRadius: 2, rows:3, stepAngle:20, startAngle:045, endAngle:135, color: 0x007701},
    {innerRadius: 2, outerRadius: 4, rows:3, stepAngle:20, startAngle:045, endAngle:135, color: 0x397700},
    {innerRadius: 4, outerRadius: 6, rows:3, stepAngle:20, startAngle:045, endAngle:135, color: 0x617700},
    {innerRadius: 6, outerRadius: 9, rows:3, stepAngle:20, startAngle:045, endAngle:135, color: 0x776f00},
    {innerRadius: 9, outerRadius:12, rows:3, stepAngle:20, startAngle:045, endAngle:135, color: 0x775500},
    {innerRadius:12, outerRadius:16, rows:3, stepAngle:20, startAngle:045, endAngle:135, color: 0x773b00},
    {innerRadius:16, outerRadius:21, rows:3, stepAngle:20, startAngle:045, endAngle:135, color: 0x771b00},
];

var vendor_color={}
vendor_color["meizu"  ] = 0xff00b2;
vendor_color["xiaomi" ] = 0xff7200;
vendor_color["huawei" ] = 0xaf0b00;
vendor_color["samsung"] = 0x2007c4;
vendor_color["apple"  ] = 0xffffff;
vendor_color["vivo"   ] = 0x00f6ff;
vendor_color["intel"  ] = 0x0464e2;
vendor_color["oppo"   ] = 0x00b247;
vendor_color["lenovo" ] = 0x8300ff;
vendor_color["htc"    ] = 0xb7ff4c;

var animations = []

var trans_down=0;
var station_top_sphere;


function draw_station(){
    var cylinder_geometry = new THREE.CylinderGeometry(0, 0.2, 1, 20);
    var cylinder_material = new THREE.MeshBasicMaterial({color: 0xc0e204});
    var geometry = new THREE.SphereGeometry(0.15, 20, 20);
    var material = new THREE.MeshBasicMaterial({color: 0xffffff});
    station_top_sphere = new THREE.Mesh(geometry, material);
    scene.add(station_top_sphere);
    station_top_sphere.position.set(0,0.2,0);
    var cylinder = new THREE.Mesh(cylinder_geometry, cylinder_material);
    cylinder.position.set(0,-0.5,0);
    scene.add(cylinder);
}


function draw_ring(fillcolor, radius){
    var segments = 60;
    var material = new THREE.MeshBasicMaterial( { color: fillcolor, side: THREE.DoubleSide } );
    var geometry = new THREE.CircleGeometry( radius, segments );
    var mesh = new THREE.Mesh( geometry, material );
    
    trans_down+=0.01;
    mesh.position.set(0,-1-trans_down,0);
    mesh.rotation.set(Math.PI/2,0,0);
    
    scene.add(mesh);
}

function draw_rings(){
    for(var uno in rings){
        uno = rings[uno];
        draw_ring(uno.color, uno.outerRadius);
    }
}

function draw_grid(){
    var bound = 5, step = 0.5, height=-1;
    var geometry_lineset = new THREE.Geometry();
    for(var i=-bound; i<=bound; i+=step){
        geometry_lineset.vertices.push(new THREE.Vector3(-bound, height, i));
        geometry_lineset.vertices.push(new THREE.Vector3( bound, height, i));
        geometry_lineset.vertices.push(new THREE.Vector3(i, height, -bound));
        geometry_lineset.vertices.push(new THREE.Vector3(i, height,  bound));
    }
    var material_line = new THREE.LineBasicMaterial({color:0xffffff});
    var grid = new THREE.LineSegments(geometry_lineset, material_line);
    scene.add(grid);
}

var scanline;
function draw_scanLine(){
    var geometry = new THREE.BoxGeometry(21,0.1,0.2);
    var material = new THREE.MeshBasicMaterial({color: 0xffff00});
    scanline = new THREE.Mesh(geometry, material);
    
    scene.add(scanline);
}


var cylinder_geometry = new THREE.CylinderGeometry(0.2, 0, 1, 20);
function draw_Device(radius, dAngle, boardColor, text){
    if(!boardColor) boardColor = 0xaaaaaa;
    dAngle = (dAngle - 90) * Math.PI / 180;
    var cylinder = new THREE.Mesh(cylinder_geometry, cylinder_material);
    var cylinder_material = new THREE.MeshBasicMaterial();
    cylinder.material.color.setHex(boardColor);
    cylinder.position.set(radius*Math.cos(dAngle), -0.5, radius*Math.sin(dAngle));
    scene.add(cylinder);
    return cylinder;
}

draw_station();
draw_rings();
draw_scanLine();

camera.position.z = 5;

var speed = 30;
function render(){

    requestAnimationFrame(render);
    if(online > 0)
        tiempo+=1;
    // camera.position.set(3*Math.sin(tiempo/100), 5, 3*Math.cos(tiempo/100));
    scanline.position.set(0,-1,0);
    scanline.rotation.set(0,-tiempo/speed,0);
    scanline.position.set(10.5*Math.cos(tiempo/speed),-1,10.5*Math.sin(tiempo/speed));
    camera.position.set(-3,10,0);
    camera.lookAt(new THREE.Vector3(4,0,0));
    renderer.render(scene, camera);
    station_top_sphere.material.color.setHex(0xffffff); 
    if(SpecialList){
        for(var key in SpecialList){
            var espacio = DeviceDict[key];
            if(espacio && espacio.SceneObj){
                if(!espacio.alt_color){
                    espacio.bright = 1;
                    espacio.alt_color = 0x010101;
                    espacio.d = 1;
                }
                else{
                    espacio.bright+=espacio.d;
                    if(espacio.bright == 5){
                        espacio.d = -1;
                        espacio.SceneObj.material.color.setHex(espacio.alt_color);
                    }
                    if(espacio.bright == 0){
                        espacio.d = 1;
                        espacio.SceneObj.material.color.setHex(espacio.ori_color);
                    }
                }
            }
            
        }
    }
}

function viewUpdate(item){
    online = Date.now();
    // tiempo+=2;
    if(station_top_sphere){
        station_top_sphere.material.color.setHex(0xff0000); 
    }
    
    if(DeviceDict[item.mac]){
        var obj = DeviceDict[item.mac];
        if(obj.SceneObj){
            scene.remove(obj.SceneObj);
        }
        
        
        
        if(!obj.Color){
            for(var key in vendor_color){
                if(obj.Vendor && obj.Vendor.indexOf(key)>=0){
                    // console.log(key);
                    obj.color = vendor_color[key];
                    obj.vendor_abbr = key;
                }
            }
            if(!obj.color) 
            {
                console.log(obj.Vendor);
                obj.color = 0xaaaaaa;
            }
            
        }
        if(!obj.dAngle)
        {
            obj.dAngle = Math.random()*90+45;
        }
        var rad = (item.sig - 40)/80 * 21;
        if(rad == 21){
            rad = 21 - Math.random()*4;
        }
        obj.ori_color = obj.color;
        obj.SceneObj = draw_Device(rad, 
                        obj.dAngle, obj.color, 'HOLA');
    }
}

window.setInterval(function(){
    if(online < Date.now() - 3000)
    {
        online = 0;
    }
    
}, 1000);

function viewDelete(obj){
    scene.remove(obj.SceneObj);
}
render();